# Projeto: SQL para Análise de Negócios

## 📌 Objetivo do Projeto
Este projeto tem como objetivo demonstrar a aplicação de consultas SQL para análise de negócios utilizando um banco de dados fictício.

## 🏢 Sobre a Empresa Fictícia - TechSales Inc.
A **TechSales Inc.** é uma empresa fictícia de tecnologia especializada na venda de eletrônicos e acessórios.

## 📊 Estrutura do Banco de Dados
- **clientes**: Informações dos clientes.
- **produtos**: Dados dos produtos vendidos.
- **vendas**: Registra as transações de vendas.

## 🔍 Consultas e Insights Obtidos

### 1️⃣ Total de Vendas por Produto
```sql
SELECT p.nome AS Produto, SUM(v.quantidade) AS Total_Vendido, SUM(v.valor_total) AS Receita_Total
FROM vendas v
JOIN produtos p ON v.produto_id = p.produto_id
GROUP BY p.nome
ORDER BY Receita_Total DESC;
```

### 2️⃣ Clientes que Mais Compraram
```sql
SELECT c.nome AS Cliente, COUNT(v.venda_id) AS Total_Compras, SUM(v.valor_total) AS Valor_Gasto
FROM vendas v
JOIN clientes c ON v.cliente_id = c.cliente_id
GROUP BY c.nome
ORDER BY Valor_Gasto DESC;
```

### 3️⃣ Receita Total por Estado
```sql
SELECT c.estado AS Estado, SUM(v.valor_total) AS Receita_Total
FROM vendas v
JOIN clientes c ON v.cliente_id = c.cliente_id
GROUP BY c.estado
ORDER BY Receita_Total DESC;
```

## 📌 Conclusão
Este projeto demonstra como SQL pode ser usado para extrair insights valiosos de um banco de dados comercial.

🔗 **LinkedIn:** [Fernando Costa de Oliveira](https://www.linkedin.com/in/fernando-costa-de-oliveira-97b124348)
📧 **Contato:** [Seu E-mail ou Site Pessoal]